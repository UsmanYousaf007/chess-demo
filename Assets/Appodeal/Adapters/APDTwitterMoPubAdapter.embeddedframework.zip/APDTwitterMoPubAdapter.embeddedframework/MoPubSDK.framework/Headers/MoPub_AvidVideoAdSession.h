//
//  AvidVideoAdSession.h
//  AppVerificationLibrary
//
//  Created by Evgeniy Gubin on 17.06.16.
//  Copyright © 2016 Integral. All rights reserved.
//

#import "MoPub_AbstractAvidAdSession.h"

@interface MoPub_AvidVideoAdSession : MoPub_AbstractAvidAdSession

@end
